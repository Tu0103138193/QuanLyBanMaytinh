﻿
namespace QuanLyBanMaytinh
{
    partial class Hang_hoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.btnTimkiem = new System.Windows.Forms.Button();
            this.btnLammoi = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.gdvHanghoa = new System.Windows.Forms.DataGridView();
            this.txtDactinh = new System.Windows.Forms.TextBox();
            this.txtmau = new System.Windows.Forms.TextBox();
            this.txtTenhang = new System.Windows.Forms.TextBox();
            this.txtMahang = new System.Windows.Forms.TextBox();
            this.cc = new System.Windows.Forms.Label();
            this.ms = new System.Windows.Forms.Label();
            this.tenh = new System.Windows.Forms.Label();
            this.lblmahang = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblsl = new System.Windows.Forms.Label();
            this.txtManhom = new System.Windows.Forms.TextBox();
            this.txtSL = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gdvHanghoa)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label8.Location = new System.Drawing.Point(12, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Hàng Hóa";
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnTimkiem.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnTimkiem.Location = new System.Drawing.Point(675, 175);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(75, 23);
            this.btnTimkiem.TabIndex = 34;
            this.btnTimkiem.Text = "Tìm kiếm";
            this.btnTimkiem.UseVisualStyleBackColor = false;
            // 
            // btnLammoi
            // 
            this.btnLammoi.BackColor = System.Drawing.Color.Fuchsia;
            this.btnLammoi.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnLammoi.Location = new System.Drawing.Point(675, 137);
            this.btnLammoi.Name = "btnLammoi";
            this.btnLammoi.Size = new System.Drawing.Size(75, 23);
            this.btnLammoi.TabIndex = 33;
            this.btnLammoi.Text = "Làm mới";
            this.btnLammoi.UseVisualStyleBackColor = false;
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Crimson;
            this.btnXoa.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnXoa.Location = new System.Drawing.Point(675, 99);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 23);
            this.btnXoa.TabIndex = 32;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.Blue;
            this.btnSua.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSua.Location = new System.Drawing.Point(675, 61);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 23);
            this.btnSua.TabIndex = 31;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnThem.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnThem.Location = new System.Drawing.Point(675, 23);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 23);
            this.btnThem.TabIndex = 30;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            // 
            // gdvHanghoa
            // 
            this.gdvHanghoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdvHanghoa.Location = new System.Drawing.Point(3, 224);
            this.gdvHanghoa.Name = "gdvHanghoa";
            this.gdvHanghoa.RowHeadersWidth = 51;
            this.gdvHanghoa.RowTemplate.Height = 24;
            this.gdvHanghoa.Size = new System.Drawing.Size(795, 220);
            this.gdvHanghoa.TabIndex = 29;
            // 
            // txtDactinh
            // 
            this.txtDactinh.Location = new System.Drawing.Point(461, 138);
            this.txtDactinh.Name = "txtDactinh";
            this.txtDactinh.Size = new System.Drawing.Size(157, 22);
            this.txtDactinh.TabIndex = 24;
            // 
            // txtmau
            // 
            this.txtmau.Location = new System.Drawing.Point(145, 139);
            this.txtmau.Name = "txtmau";
            this.txtmau.Size = new System.Drawing.Size(157, 22);
            this.txtmau.TabIndex = 23;
            // 
            // txtTenhang
            // 
            this.txtTenhang.Location = new System.Drawing.Point(145, 99);
            this.txtTenhang.Name = "txtTenhang";
            this.txtTenhang.Size = new System.Drawing.Size(157, 22);
            this.txtTenhang.TabIndex = 22;
            // 
            // txtMahang
            // 
            this.txtMahang.Location = new System.Drawing.Point(145, 54);
            this.txtMahang.Name = "txtMahang";
            this.txtMahang.Size = new System.Drawing.Size(157, 22);
            this.txtMahang.TabIndex = 21;
            // 
            // cc
            // 
            this.cc.AutoSize = true;
            this.cc.Location = new System.Drawing.Point(343, 143);
            this.cc.Name = "cc";
            this.cc.Size = new System.Drawing.Size(114, 17);
            this.cc.TabIndex = 17;
            this.cc.Text = "Đặc tính kỹ thuật";
            // 
            // ms
            // 
            this.ms.AutoSize = true;
            this.ms.Location = new System.Drawing.Point(27, 144);
            this.ms.Name = "ms";
            this.ms.Size = new System.Drawing.Size(61, 17);
            this.ms.TabIndex = 16;
            this.ms.Text = "Màu sắc";
            // 
            // tenh
            // 
            this.tenh.AutoSize = true;
            this.tenh.Location = new System.Drawing.Point(27, 102);
            this.tenh.Name = "tenh";
            this.tenh.Size = new System.Drawing.Size(69, 17);
            this.tenh.TabIndex = 15;
            this.tenh.Text = "Tên hàng";
            // 
            // lblmahang
            // 
            this.lblmahang.AutoSize = true;
            this.lblmahang.Location = new System.Drawing.Point(27, 60);
            this.lblmahang.Name = "lblmahang";
            this.lblmahang.Size = new System.Drawing.Size(63, 17);
            this.lblmahang.TabIndex = 14;
            this.lblmahang.Text = "Mã hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(343, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Mã Nhóm";
            // 
            // lblsl
            // 
            this.lblsl.AutoSize = true;
            this.lblsl.Location = new System.Drawing.Point(343, 100);
            this.lblsl.Name = "lblsl";
            this.lblsl.Size = new System.Drawing.Size(64, 17);
            this.lblsl.TabIndex = 15;
            this.lblsl.Text = "Số lượng";
            // 
            // txtManhom
            // 
            this.txtManhom.Location = new System.Drawing.Point(461, 52);
            this.txtManhom.Name = "txtManhom";
            this.txtManhom.Size = new System.Drawing.Size(157, 22);
            this.txtManhom.TabIndex = 21;
            // 
            // txtSL
            // 
            this.txtSL.Location = new System.Drawing.Point(461, 97);
            this.txtSL.Name = "txtSL";
            this.txtSL.Size = new System.Drawing.Size(157, 22);
            this.txtSL.TabIndex = 22;
            // 
            // Hang_hoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnTimkiem);
            this.Controls.Add(this.btnLammoi);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.gdvHanghoa);
            this.Controls.Add(this.txtDactinh);
            this.Controls.Add(this.txtSL);
            this.Controls.Add(this.txtmau);
            this.Controls.Add(this.txtManhom);
            this.Controls.Add(this.txtTenhang);
            this.Controls.Add(this.txtMahang);
            this.Controls.Add(this.cc);
            this.Controls.Add(this.lblsl);
            this.Controls.Add(this.ms);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tenh);
            this.Controls.Add(this.lblmahang);
            this.Name = "Hang_hoa";
            this.Text = "Hàng Hóa";
            ((System.ComponentModel.ISupportInitialize)(this.gdvHanghoa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnTimkiem;
        private System.Windows.Forms.Button btnLammoi;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView gdvHanghoa;
        private System.Windows.Forms.TextBox txtDactinh;
        private System.Windows.Forms.TextBox txtmau;
        private System.Windows.Forms.TextBox txtTenhang;
        private System.Windows.Forms.TextBox txtMahang;
        private System.Windows.Forms.Label cc;
        private System.Windows.Forms.Label ms;
        private System.Windows.Forms.Label tenh;
        private System.Windows.Forms.Label lblmahang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblsl;
        private System.Windows.Forms.TextBox txtManhom;
        private System.Windows.Forms.TextBox txtSL;
    }
}